/* custom js for the subscription view page */

/*jslint indent: 2 */
/*global CRM, ts */

cj(function ($) {
  'use strict';
  $('table.crm-info-panel').append($('#iats-extra tr'));
});

