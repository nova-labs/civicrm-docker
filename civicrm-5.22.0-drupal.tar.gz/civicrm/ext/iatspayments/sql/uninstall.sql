DROP TABLE IF EXISTS `civicrm_iats_customer_codes`;
DROP TABLE IF EXISTS `civicrm_iats_request_log`;
DROP TABLE IF EXISTS `civicrm_iats_response_log`;
DROP TABLE IF EXISTS `civicrm_iats_verify`;
DROP TABLE IF EXISTS `civicrm_iats_ukdd_validate`;
DROP TABLE IF EXISTS `civicrm_iats_journal`;
DROP TABLE IF EXISTS `civicrm_iats_faps_journal`;
